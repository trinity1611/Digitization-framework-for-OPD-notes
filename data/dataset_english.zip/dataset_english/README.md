# dataset_english (subset of Prescription_Dataset(600))

Built on 2026-11-13 by viewing every one of the 600 images by eye (no OCR / no MedGemma
or any other model was used to decide). The full per-image verdict table is
`script_verdicts_all600.csv`.

Inclusion rule: every handwritten part of the prescription (drug names, doses,
frequencies such as 1+0+1, durations, advice, dates) is in Latin letters / Western
digits. A page was excluded as soon as any Bangla handwriting appeared, even a single
"৭ দিন" or "১+০+১".

| category | meaning | count | where |
|---|---|---|---|
| E  | all handwriting English, no Bangla anywhere except the pre-printed footer of the government form | 59 | `images/`, `dataset_english.csv` |
| EP | all handwriting English, but the clinic letterhead / stamp is printed in Bangla | 18 | `images/`, `dataset_english.csv` (filter on `category`) |
| PE | printed English hospital form with ticks only, no handwritten text | 15 | not moved; listed in `not_moved_printed_english_forms.csv` |
| U  | could not decide from the image (illegible or mixed) | 5 | not moved; listed in `not_moved_uncertain.csv` |
| B  | Bangla handwriting present (dosing, duration, advice, or whole page) | 503 | left in `../images/Prescription images.jpg/` |

`dataset_english.csv` columns: `image_filename, category, description_english` (E and EP rows only, Bangla column dropped).
The descriptions are copied verbatim from `../Prescription Dataset.csv` (the original is
untouched). Note that the original CSV is malformed (unescaped quotes / commas and
line breaks inside descriptions); rows were re-assembled by filename and split at the
first Bangla character, so compare against the original if a description looks truncated.

The English description is a sentence-level paraphrase of the prescription, not a
verbatim transcription (see ../../../../DATASETS.md).
